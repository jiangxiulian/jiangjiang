package com.shxt.utils;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MyBatisUtils {
	private MyBatisUtils(){};
	private static SqlSessionFactory sqlSessionFactory=null;
	private static final String PATH="config.xml";
	private static InputStream inputStream = null;
	static{
		try{
			inputStream=Resources.getResourceAsStream(PATH);
			sqlSessionFactory =new SqlSessionFactoryBuilder().build(inputStream);
		}catch(Exception e){
			System.out.println("加载MyBatis核心文件错误。异常信息为："+e.getMessage());
		}
	}
	public static SqlSession getSqlSession(){
		return sqlSessionFactory.openSession();
	}
	public static void closeSqlSession(SqlSession sqlSession){
		if(sqlSession!=null)sqlSession.close();
	}
}
