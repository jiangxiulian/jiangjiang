package com.shxt.model;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class 更新操作 implements Serializable {
	public static void main(String[] args){
		//读取配置文件
		String path="config.xml";
		SqlSession sqlSession=null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(path);
			//2.创建SQLSessionFactory工厂
			SqlSessionFactory  sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
			sqlSession =sqlSessionFactory.openSession();
			
			//执行定制的sql语句；
			//第一种  没有添加的属性会更新为null
			User user = new User();
			user.setAccount("songjiang");
			user.setPwd("123");
			user.setUserName("姜秀连");
			user.setUserId(5);
			
			System.out.println(sqlSession.update("shxt.xy37.update", user));
			
			//第二种  另有一种框架必须这么更新
			/*User user=sqlSession.selectOne("shxt.xy37.load", 3);
			user.setUserName("林俊杰");
			sqlSession.update("shxt.xy37.update",user);*/
			
			//事务提交；
			sqlSession.commit();
			System.out.println(user);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			if(sqlSession!=null) sqlSession.close();
		}
	}

}
