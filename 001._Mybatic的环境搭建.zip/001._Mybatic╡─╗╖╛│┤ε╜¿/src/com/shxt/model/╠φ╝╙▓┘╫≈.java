package com.shxt.model;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class 添加操作 implements Serializable {
	public static void main(String[] args){
		//读取配置文件
		String path="config.xml";
		SqlSession sqlSession=null;
		try {
			InputStream inputStream = Resources.getResourceAsStream(path);
			//2.创建SQLSessionFactory工厂
			SqlSessionFactory  sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
			sqlSession =sqlSessionFactory.openSession();
			
			User user = new User();
			user.setAccount("songjiang");
			user.setPwd("123");
			user.setUserName("宋江");
			
			//执行定制的sql语句；
			sqlSession.insert("shxt.xy37.add",user);
			//事务提交；
			sqlSession.commit();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			if(sqlSession!=null) sqlSession.close();
		}
	}

}
